const INITIAL_STATE = {
    searchAlbums:[],
    searchArtist:[],
    artistsData:[],
    tracksData:[],
    
  };
  
  const dataReducer = (state = INITIAL_STATE, action) => {
    switch (action.type) {
      case "SEARCHALBUMS":
        return{
          ...state,
          searchData: [...state.searchData, action.payload]
        }
        case "SEARCHARTISTS":
          return{
            ...state,
            artistsData: [...state.artistsData, action.payload]
          }
    
          case "ALBUMS":
          return{
            ...state,
            allAlbums: [...state.allAlbums, action.payload]
          }
    
          case "TRACKS":
            return{
              ...state,
              tracksData: [...state.tracksData, action.payload]
            }
      default:
        return state;
    }
  };
  export default dataReducer;