export const keyGenerator = (length) => {
  const characters = "0123456789";
  const result = Array.from({ length })
    .map(
      (e, i) =>
        characters[Math.floor(Math.random() * characters.length)] +
        (!((i + 1) % 4) ? "-" : "")
    )
    .join("")
    .slice(0, -1);
  return result;
};

export const validateText = (text) => {
  if (typeof text === "string" && text.trim().length) {
    return text;
  }else
  {return false}
  
};

export const longText = (text, n) => {
  if (typeof text === "string" && text.trim().length) {
    if (text.length > 20) {
      return text.slice(0, n) + "...";
    } else {
      return text;
    }
  }
};

export const asic = {
  method: "GET",
  headers: {
    Accept: "application/json",
    "Content-Type": "application/json",
    Authorization:
     "Bearer BQBQAIBDQfM9rqdobyaTAhQf166xeZvo8tkQa_OFOdDodqjfT03a7ifpW6-i3HsrlQuohChgzKV7Zb52ZKFrS0Xx9MtaNJw1AopOXgtzqsm5jTqLKgCqgQNoYsfwFz6IhJBSamDhwLCOVhl_iz0uw_Az1NThA4rbWIo-M99ryh3F8VXecOxoX1FiGmce4XLPe06vfKrSy7M"
    },

}

export const getFechData = (artists, idArtist, albums) => {
  fetch(
    "https://api.spotify.com/v1/" + artists + "/" + idArtist + "/" + albums,
    asic
  )
    .then((response) => response.json())
    .then((data) => {
      console.log("artist");
      console.log(data.items);
      console.log(Array.isArray(data.items));
      if (data) {
        if (Array.isArray(data.items)) {
          return data.items;
        }
      }
    });
};

export const checkToken = (token) => {

  let asic = {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization:
        {token},
    },
  };

  return asic;
};
