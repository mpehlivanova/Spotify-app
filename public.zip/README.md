# Spotify-app
![artist](https://user-images.githubusercontent.com/97164252/172145298-9975964a-7283-4f01-a577-c9065942cf57.PNG)
![album](https://user-images.githubusercontent.com/97164252/172144520-b3919db4-a0ed-40f8-bf96-bb6ebdbdad20.PNG)
